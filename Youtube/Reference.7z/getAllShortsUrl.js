javascript:(function() {
	let allUrls = '';
	let allShorts = document.querySelectorAll('a.shortsLockupViewModelHostEndpoint');
	for (var i in allShorts)
	{
		let thisUrl = allShorts[i].href;
		console.log(thisUrl);
		if (thisUrl.indexOf('/shorts/') < 0) continue;
		allUrls += location.origin + thisUrl + '\n';
	}
	navigator.clipboard.writeText(allUrls);
	alert('All short urls copied.');
})()